package com.example.listclub;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class FootballAdapter extends RecyclerView.Adapter<FootballAdapter.ViewHolder> {

    private Context context;
    private ArrayList<FootballModel> footballModels;

    public FootballAdapter(Context context) {
        this.context = context;
    }

    public ArrayList<FootballModel> getFootballModels() {
        return footballModels;
    }

    public void setFootballModels(ArrayList<FootballModel> footballModels) {
        this.footballModels = footballModels;
    }

    @NonNull
    @Override
    public FootballAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemRow = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_club,viewGroup,false);
        return new ViewHolder(itemRow);
    }

    @Override
    public void onBindViewHolder(@NonNull FootballAdapter.ViewHolder viewHolder, int i) {
        Glide.with(context).load(getFootballModels().get(i).getLogoclub()).into(viewHolder.logoclub);
        viewHolder.namaclub.setText(getFootballModels().get(i).getNamaclub());
    }

    @Override
    public int getItemCount() {
        return getFootballModels().size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private ImageView logoclub;
        private TextView namaclub;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            logoclub = itemView.findViewById(R.id.logoclub);
            namaclub = itemView.findViewById(R.id.namaclub);
        }
    }
}
