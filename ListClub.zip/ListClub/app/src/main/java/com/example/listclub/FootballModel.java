package com.example.listclub;

import android.widget.ImageView;
import android.widget.TextView;

public class FootballModel {

    private String namaclub;
    private int logoclub;

    public String getNamaclub() {
        return namaclub;
    }

    public void setNamaclub(String namaclub) {
        this.namaclub = namaclub;
    }

    public int getLogoclub() {
        return logoclub;
    }

    public void setLogoclub(int logoclub) {
        this.logoclub = logoclub;
    }

}
